import React from 'react';
import ReactDOM from 'react-dom/client';
import EduPilot from './EduPilot';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <EduPilot />
  </React.StrictMode>
);